# EOG Sword x Staff Polished Discord Bot

A clean, menu-driven Discord bot that pulls public **Sword x Staff** info from **EOG.GG**, organizes it into player-friendly categories, and answers natural player questions.

## Player commands

### Main menu

```text
/sxs
```

Opens a polished Sword x Staff info hub with category dropdowns.

### Ask the bot

```text
/ask question:best sage build
/ask question:what are the latest codes
/ask question:what fantomon should sage use
/ask question:tier list
```

The bot searches the cached EOG catalog and returns the most relevant answer in a clean embed.

### Search

```text
/sxs-search query:sage dark healer
```

Returns multiple matching results.

### Refresh

```text
/sxs-refresh
```

Admin-only manual refresh. The bot also refreshes automatically.

## Visual organization

The bot uses styled embeds, emojis, consistent category labels, source buttons, and compact summaries.

Categories:

- 🧭 Overview
- 🏆 Tier List
- 📘 Guides
- ⚔️ Builds
- 🗃️ Database
- 🗺️ Roadmap
- 🎁 Codes
- ✅ Verdict
- 🔎 Other

## Auto-updating

The bot crawls from:

```text
https://eog.gg/games/sword-x-staff/
```

It follows internal Sword x Staff links, extracts titles, descriptions, images, headings, list items, and useful text, then rebuilds the catalog every `CACHE_MINUTES`.

## Setup

```bash
npm install
cp .env.example .env
```

Fill in:

```env
DISCORD_TOKEN=...
DISCORD_CLIENT_ID=...
DISCORD_GUILD_ID=...
```

Register commands:

```bash
npm run deploy
```

Start:

```bash
npm start
```

## Notes

- This reads public EOG.GG pages only.
- It keeps EOG source links visible.
- It caches results to avoid repeatedly hitting the site.
