import { crawlEog } from './crawler.js';
import { categoryLabel } from './theme.js';

const BASE_URL = process.env.EOG_BASE_URL || 'https://eog.gg/games/sword-x-staff/';
const CACHE_MINUTES = Number(process.env.CACHE_MINUTES || 30);
const CACHE_MS = CACHE_MINUTES * 60 * 1000;

let catalog = {
  sourceUrl: BASE_URL,
  updatedAt: null,
  items: []
};

const CATEGORY_ORDER = [
  'overview',
  'tier-list',
  'guides',
  'builds',
  'database',
  'roadmap',
  'codes',
  'verdict',
  'other'
];

export async function getCatalog() {
  const now = Date.now();

  if (!catalog.updatedAt || now - new Date(catalog.updatedAt).getTime() > CACHE_MS) {
    await refreshCatalog();
  }

  return catalog;
}

export async function refreshCatalog(force = false) {
  if (!force && catalog.updatedAt && Date.now() - new Date(catalog.updatedAt).getTime() < CACHE_MS) {
    return catalog;
  }

  catalog = await crawlEog(BASE_URL);
  return catalog;
}

export function getCategories() {
  const available = new Set(catalog.items.map(item => item.category));
  return CATEGORY_ORDER.filter(category => available.has(category));
}

export function getItemsByCategory(category) {
  return catalog.items
    .filter(item => item.category === category)
    .sort((a, b) => a.title.localeCompare(b.title));
}

export function getItemById(id) {
  return catalog.items.find(item => item.id === id);
}

export async function searchCatalog(query, limit = 10) {
  await getCatalog();

  const intent = inferIntent(query);
  const terms = tokenize(query);

  return catalog.items
    .map(item => {
      const title = item.title.toLowerCase();
      const tags = (item.tags || []).join(' ').toLowerCase();
      const headings = (item.headings || []).join(' ').toLowerCase();
      const text = [item.summary, item.category, tags, headings, item.text].join(' ').toLowerCase();

      let score = 0;

      if (intent.category && item.category === intent.category) score += 35;
      if (intent.className && text.includes(intent.className)) score += 30;
      if (intent.exactPhrases.some(phrase => title.includes(phrase))) score += 20;

      for (const term of terms) {
        if (title.includes(term)) score += 12;
        if (tags.includes(term)) score += 8;
        if (headings.includes(term)) score += 5;
        if (text.includes(term)) score += 2;
      }

      return { item, score };
    })
    .filter(result => result.score > 0)
    .sort((a, b) => b.score - a.score || a.item.title.localeCompare(b.item.title))
    .slice(0, limit)
    .map(result => ({ ...result.item, matchScore: result.score }));
}

export async function answerQuestion(question) {
  const results = await searchCatalog(question, 5);
  const best = results[0];

  if (!best) {
    return {
      found: false,
      question,
      results: [],
      answer: `I couldn't find that in the current EOG Sword x Staff catalog. Try a simpler question like “Sage build,” “codes,” or “tier list.”`
    };
  }

  const focused = buildFocusedAnswer(question, best);

  return {
    found: true,
    question,
    item: best,
    results,
    answer: focused
  };
}

function buildFocusedAnswer(question, item) {
  const q = question.toLowerCase();
  const lines = [];

  lines.push(item.summary || 'Here is the most relevant EOG result I found.');

  const usefulSections = [];

  if (q.includes('build') || q.includes('sage') || q.includes('sorcerer') || q.includes('duelist') || q.includes('knight')) {
    usefulSections.push(...extractBuildBullets(item));
  }

  if (q.includes('code') || item.category === 'codes') {
    usefulSections.push(...extractCodeBullets(item));
  }

  if (q.includes('tier') || q.includes('best') || item.category === 'tier-list') {
    usefulSections.push(...extractRecommendationBullets(item));
  }

  if (!usefulSections.length) {
    usefulSections.push(...(item.tldr || []).slice(0, 4));
  }

  if (usefulSections.length) {
    lines.push('');
    lines.push(usefulSections.slice(0, 5).map(x => `• ${x}`).join('\n'));
  }

  return lines.join('\n').slice(0, 1800);
}

function extractBuildBullets(item) {
  const text = item.text || '';
  const bullets = [];

  const fields = [
    ['Role', /role\s*:?\s*([^\.\n]{5,120})/i],
    ['Trait', /trait\s*stat\s*:?\s*([^\.\n]{5,120})/i],
    ['Element', /element\s*affinity\s*:?\s*([^\.\n]{3,120})/i],
    ['Stat Focus', /stat\s*focus\s*:?\s*([^\.\n]{5,180})/i],
    ['Fantomon', /fantomon\s*:?\s*([^\.\n]{5,180})/i]
  ];

  for (const [label, regex] of fields) {
    const match = text.match(regex);
    if (match) bullets.push(`**${label}:** ${match[1].trim()}`);
  }

  return bullets.length ? bullets : (item.tldr || []).slice(0, 5);
}

function extractCodeBullets(item) {
  return (item.tldr || [])
    .filter(line => /code|redeem|reward|free|active|expired/i.test(line))
    .slice(0, 5);
}

function extractRecommendationBullets(item) {
  return (item.tldr || [])
    .filter(line => /best|tier|rank|recommend|meta|strong|pick/i.test(line))
    .slice(0, 5);
}

function inferIntent(query) {
  const q = query.toLowerCase();
  let category = null;

  if (q.includes('tier') || q.includes('best')) category = 'tier-list';
  if (q.includes('build') || q.includes('sage') || q.includes('sorcerer') || q.includes('duelist') || q.includes('knight')) category = 'builds';
  if (q.includes('code') || q.includes('redeem')) category = 'codes';
  if (q.includes('roadmap') || q.includes('update') || q.includes('coming')) category = 'roadmap';
  if (q.includes('skill') || q.includes('fantomon') || q.includes('companion') || q.includes('database')) category = 'database';
  if (q.includes('guide') || q.includes('how')) category = 'guides';

  const className = ['sage', 'sorcerer', 'duelist', 'knight'].find(name => q.includes(name)) || null;
  const exactPhrases = ['tier list', 'best build', 'sage build', 'latest codes', 'redeem codes'].filter(p => q.includes(p));

  return { category, className, exactPhrases };
}

function tokenize(query) {
  const stop = new Set(['the', 'a', 'an', 'for', 'to', 'is', 'are', 'what', 'which', 'how', 'do', 'i', 'get', 'info', 'about']);
  return query
    .toLowerCase()
    .split(/\W+/)
    .filter(word => word.length > 2 && !stop.has(word));
}

export { categoryLabel };
